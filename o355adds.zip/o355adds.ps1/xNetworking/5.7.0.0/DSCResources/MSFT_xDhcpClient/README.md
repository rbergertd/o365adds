# Description

The resource is responsible for creating and managing DHCP Clients for a network
interface on a node.
